package practiceprojects_servlets;

import javax.servlet.*;

import java.io.*;
public class LoginFilter implements Filter {
	
	public void destroy(){
		
	}
	public void doFilter(ServletRequest request, ServletResponse response,FilterChain chain)throws IOException,ServletException{
		System.out.println("In Login filter class...");
		String emailid=request.getParameter("Email");
		String pass= request.getParameter("Password");
		
		if("anusha@gmail.com".equals(emailid) && "anu".equals(pass)){
			
			System.out.println("Passing through DataChecker filter..");
			response.getWriter().write("Successfully Logged in...\n");
			chain.doFilter(request, response);
			System.out.println("In Login filter after doFilter\n");
		}
		else
			response.getWriter().write("Invalid Credentials...");
			
	}
	
	public void init(FilterConfig fConfig) throws ServletException {
		
	}
 
		
}





