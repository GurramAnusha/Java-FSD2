package com.simplilearn.demo;

public class Authentication {
	public boolean authentication(String username,String password) {
		if(username=="anusha"& password=="anusha@123") {
			return true;
		}
		else {
			return false;
		}
	}

}
