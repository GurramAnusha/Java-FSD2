package TestNg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
@Test
public class AutomateWebApp {
WebDriver driver;

	@BeforeTest
	public void beforeMethod() {
		 System.setProperty("webdriver.chrome.driver", "D:\\chromedriver_win32\\chromedriver.exe");
		 driver = new ChromeDriver(); // this intializes the chrome web browser		 
		 System.out.println("In beforeMethod.....");
	}

	@AfterTest
	public void afterMethod() {
		//driver.close();
		driver=null;
		System.out.println("In afterMethod.....");
	}
	
	public void search() throws InterruptedException {
		driver.get("http://amazon.com");
		driver.manage().window().maximize(); // this enables the browser to maximize its width and height
	    Thread.sleep(4000);
	    driver.findElement(By.id("twotabsearchtextbox")).sendKeys("pen drives");
	    driver.findElement(By.id("nav-search-submit-button")).click();
	    driver.findElement(By.linkText("SanDisk")).click();
	    driver.findElement(By.partialLinkText("SanDisk 128GB Cruzer USB 2.0 Flash Drive - SDCZ36-128G-B35")).click();
	}
	
	public void addToCart() throws InterruptedException {
		driver.get("https://www.amazon.com/SanDisk-Cruzer-128GB-Flash-SDCZ36-128G-B35/dp/B00TKFCYP0/ref=sr_1_1?keywords=pen+drives&qid=1665156139&qu=eyJxc2MiOiIzLjk5IiwicXNhIjoiMy44NiIsInFzcCI6IjMuNjUifQ%3D%3D&refinements=p_89%3ASanDisk&rnid=2528832011&s=electronics&sr=1-1");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@title='Add to Shopping Cart']")).click();
	}
		
		public void register() throws InterruptedException {
		driver.get("https://www.amazon.com/ap/register?showRememberMe=true&openid.pape.max_auth_age=0&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&pageId=usflex&mobileBrowserWeblabTreatment=C&openid.return_to=https%3A%2F%2Fwww.amazon.com%2F%3F_encoding%3DUTF8%26ref_%3Dnav_em_hd_re_signin&prevRID=X0PWH6ZFC1NW9PMJWVG3&openid.assoc_handle=usflex&openid.mode=checkid_setup&desktopBrowserWeblabTreatment=C&prepopulatedLoginId=&failedSignInCount=0&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0");
		Thread.sleep(2000);
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.findElement(By.name("customerName")).sendKeys("Anusha");	
		Thread.sleep(2000);
		driver.findElement(By.name("email")).sendKeys("anusha@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.name("password")).sendKeys("Anu@123");
		Thread.sleep(2000);
		driver.findElement(By.name("passwordCheck")).sendKeys("Anu@123");
		Thread.sleep(10000);
		driver.findElement(By.id("continue")).submit();	
	}
	public void login() throws InterruptedException {
		driver.get("https://www.amazon.in/ap/signin?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.in%2F%3Fref_%3Dnav_signin&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=inflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&");
		Thread.sleep(2000);
		driver.findElement(By.name("email")).sendKeys("anusha@gmail.com");
		driver.findElement(By.id("continue")).submit();	
	}
	
}
