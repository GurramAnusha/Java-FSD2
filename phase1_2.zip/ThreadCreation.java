package assistedpractice_phase1_2;
//creation of thread by extending Thread class
/*public class ThreadCreation extends Thread{
	
	public void run(){
		System.out.println("concurrent thread started running");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThreadCreation t=new ThreadCreation();
		t.start();

	}

}*/

//creation of thread by implementing Runnable interface
public class ThreadCreation implements Runnable{
	public static int count=0;
	public void run(){
		System.out.println("Thread is running..");
		while(ThreadCreation.count<=10){
			try{
				System.out.println("Thread1:"+(++ThreadCreation.count));
				Thread.sleep(100);
			}
			catch(Exception e){
				System.out.println(e.getMessage());
			}
		}
	}
	public static void main(String args[]){
		ThreadCreation t=new ThreadCreation();
		Thread tr=new Thread(t);
		tr.start();
	}
	
}





