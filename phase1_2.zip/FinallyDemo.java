package assistedpractice_phase1_2;

public class FinallyDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10,b=0,rs=0;
		try{
			rs=a/b;
		}
		catch(ArithmeticException e){
			System.out.println(e.getMessage());
		}
		finally{
			System.out.println("The result is:"+rs);
		}

	}

}
