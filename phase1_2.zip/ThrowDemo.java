package assistedpractice_phase1_2;

public class ThrowDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=45,b=0,rs;
		try{
			if(b==0)
				throw new ArithmeticException("Cannot divide by zero");
			else{
				rs=a/b;
				System.out.println("result is:"+rs);
			}
		}
		catch(ArithmeticException e)
		{
			System.out.println(e.getMessage());
		}
		System.out.println("End of the program");
	}

}
