package assistedpractice_phase1_2;

public class ClassObjectsDemo {
	String name;
	int age;
	String color;
	ClassObjectsDemo(String name,int age, String color){
		this.name=name;
		this.age=age;
		this.color=color;
	}
	public String toString(){
		return("Name is:"+name+"\nAge is:"+age+"\ncolor is:"+color);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClassObjectsDemo c=new ClassObjectsDemo("Rocky",5,"white");
		System.out.println(c.toString());
	}

}
