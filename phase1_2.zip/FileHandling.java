package assistedpractice_phase1_2;
import java.io.*;
public class FileHandling {
	
	static void createFileUsingFileClass() throws IOException{
		File file=new File("D://Assignments//temp1.txt");
		if(file.createNewFile()){
			System.out.println("File is created");
		}
		else{
			System.out.println("File already exists");
		}
		//write content
		FileWriter w=new FileWriter(file,true);
		w.write("test data");
		w.close();
		
		//read content
		FileReader r=new FileReader(file);
		char c[]=new char[25];
		r.read(c);
		System.out.println(c);
		r.close();
		
		//delete the file
		file.delete();
	}

	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		createFileUsingFileClass();
	}

}
