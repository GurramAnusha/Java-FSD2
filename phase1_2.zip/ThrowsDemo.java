package assistedpractice_phase1_2;

public class ThrowsDemo {
	void divison()throws ArithmeticException
	{
		int a=10,b=0,rs;
		rs=a/b;
		System.out.println("The result is:"+rs);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThrowsDemo t=new ThrowsDemo();
		try{
		t.divison();
		
		}
		catch(ArithmeticException a)
		{
			System.out.println(a.getMessage());
		}

	}

}
