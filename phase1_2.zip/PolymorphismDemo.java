package assistedpractice_phase1_2;

public class PolymorphismDemo {
	public int sum(int a,int b){
		return (a+b);
	}
	public int sum(int x,int y,int z){
		return (x+y+z);
	}
	public double sum(double x,double y){
		return (x+y);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PolymorphismDemo p=new PolymorphismDemo();
		System.out.println(p.sum(10, 20));
		System.out.println(p.sum(10, 20,30));
		System.out.println(p.sum(10.5, 20.5));
	}

}
