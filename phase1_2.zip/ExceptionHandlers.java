package assistedpractice_phase1_2;

class MyException extends Exception{
	String str;
	MyException(String s){
		super(s);
	}
}

public class ExceptionHandlers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			throw new MyException("This is my error message"); 
		}
		catch(MyException e){
			System.out.println(e.getMessage());
		}

	}

}
