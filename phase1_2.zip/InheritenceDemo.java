package assistedpractice_phase1_2;

class Parent{
	int gear;
	int speed;
	Parent(int gear,int speed){
		this.gear=gear;
		this.speed=speed;
	}
	public String toString(){
		return("No of gears:"+gear+"\nSpeed is:"+speed);
	}
}

class Child extends Parent{
	int height;
	Child(int gear,int speed,int height){
		super(gear,speed);
		this.height=height;
	}
	//override
	public String toString(){
		return (super.toString()+"\nHeight is:"+height);
	}
}

public class InheritenceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Child c=new Child(10,100,25);
		System.out.println(c.toString());
	}

}
