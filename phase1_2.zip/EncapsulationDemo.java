package assistedpractice_phase1_2;

public class EncapsulationDemo {
	private String name;
	private int roll;
	private int age;
	

	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getRoll() {
		return roll;
	}


	public void setRoll(int roll) {
		this.roll = roll;
	}


	 public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EncapsulationDemo e=new EncapsulationDemo();
		e.setName("Anand");
		e.setAge(23);
		e.setRoll(51);
		System.out.println("Name is:"+e.getName());
		System.out.println("Age is:"+e.getAge());
		System.out.println("Roll is:"+e.getRoll());
	}

}
