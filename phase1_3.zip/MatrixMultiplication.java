package assistedpractice_phase1_3;
import java.util.*;
public class MatrixMultiplication {
	static int r1,r2,c1,c2;
	static int arr1[][];
	static int arr2[][];
	static int res[][];
	static void multiply(int a1[][],int a2[][],int r1,int c1,int r2,int c2 ){
		res=new int[r1][c2];
		for(int i=0;i<r1;i++){
			for(int j=0;j<c2;j++){
				for(int k=0;k<c1;k++){
					res[i][j]+=a1[i][k]*a2[k][j];
				}
			}
		}
	}
	
	static void display(){
		System.out.println("The resultant matrix is: ");
		for(int i=0;i<r1;i++){
			for(int j=0;j<c2;j++){
				System.out.print(res[i][j]+" ");
			}
			System.out.println();
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number of rows and columns of first matrix");
		r1=sc.nextInt();
		c1=sc.nextInt();
		System.out.println("Enter number of rows and columns of second matrix");
		r2=sc.nextInt();
		c2=sc.nextInt();
		if(c1==r2){
			System.out.println("Matrix multiplication is possible:");
			System.out.println("Enter the elements of the first matrix");
			arr1=new int[r1][c1];
			arr2=new int[r2][c2];
			for(int i=0;i<r1;i++){
				for(int j=0;j<c1;j++){
					arr1[i][j]=sc.nextInt();
				}
			}
			System.out.println("Enter the elements of the second matrix");
			for(int i=0;i<r2;i++){
				for(int j=0;j<c2;j++){
					arr2[i][j]=sc.nextInt();
				}
			}
			multiply(arr1,arr2,r1,c1,r2,c2);
			display();
		}
		else{
			System.out.println("Matrix multiplication is not possible");
		}

	}

}
