package assistedpractice_phase1_3;
import java.util.*;
public class SinglyLinkedList {

	static void removeKey(LinkedList l,int i){
		if(l.contains(i)){
			l.remove(l.indexOf(i));
			System.out.println(i+" is removed from the linkedlist");
		}
		else
			System.out.println(i+" is not present in the linked list");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LinkedList<Integer> l=new LinkedList<Integer>();
		l.add(1);
		l.add(2);
		l.add(3);
		l.add(4);
		System.out.println("The elements in the linked list: "+l);
		System.out.println("The head of the Linkedlist is: " +l.peek());
		removeKey(l,3);
		removeKey(l,7);
		System.out.println("After performing remove operation of specified keys the linked list is: "+l);
		
	}

}
