package assistedpractice_phase1_3;
 import java.util.*;
public class QueueDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Queue<Integer> q=new LinkedList<Integer>();
		q.add(1);
		q.add(2);
		q.add(3);
		q.add(4);
		q.add(5);
		q.add(6);
		q.add(7);
		System.out.println("Queue elements are: "+q);
		System.out.println("Head of Queue: "+q.peek());
		q.remove();
		System.out.println("After removing one element Head of Queue: "+q.peek());
		System.out.println("After removing one element Queue elements are: "+q);
		
	}

}
