package assistedpractice_phase1_3;
import java.util.*;

public class Order_Statistics {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size of the array");
		int n=sc.nextInt();
		System.out.println("Enter the elements in the array");
		int a[]=new int[n];
		for(int i=0;i<n;i++)
			a[i]=sc.nextInt();
		int k=4;
		Arrays.sort(a);
		System.out.println("The fourth smallest element in the array is: ");
		System.out.println(a[k-1]);
	}

}
