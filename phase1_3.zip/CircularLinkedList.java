package assistedpractice_phase1_3;

public class CircularLinkedList {
	static class Node{
		int data;
		Node next;
		Node(int d){
			data=d;
			next=null;
		}
	}
	Node head;
	CircularLinkedList(){
		head=null;
	}
	
	void sortedInsert(Node newnode){
		Node current=head;
		if(current==null){
			newnode.next=newnode;
			head=newnode;
		}
		else if(current.data>=newnode.data){
			while(current.next!=head)
				current=current.next;
			current.next=newnode;
			newnode.next=head;
			head=newnode;
		}
		else{
			while (current.next != head && current.next.data < newnode.data) 
    			current = current.next; 
			newnode.next = current.next; 
			current.next = newnode; 
		}
	}
	
	void printList() 
	{
		if(head!= null) 
   		{ 
        	Node temp = head; 
        	do
       		{ 
            	System.out.print(temp.data + " "); 
            	temp = temp.next; 
        	}while(temp!= head); 
   		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CircularLinkedList c=new CircularLinkedList();
		int arr[]=new int[] {12,56,2,11,1,90};
		Node temp=null;
		for(int i=0;i<6;i++){
			temp=new Node(arr[i]);
			
			c.sortedInsert(temp);
		}
		c.printList();
		System.out.println();
		c.sortedInsert(new Node(8));
		c.printList();
	}

}
