package assistedpractice_phase1_3;

public class StackDemo {
	
	static final int SIZE=100;
	int top;
	int a[]=new int[SIZE];
	StackDemo(){
		top=-1;
	}
	
	boolean isEmpty(){
		return top<0;
	}
	
	int pop(){
		if(top<0){
			System.out.println("stack underflow");
			return 0;
		}
		else{
			int x=a[top];
			top--;
			return x;
		}
			
	}
	
	void push(int x){
		if(top>=(SIZE-1)){
			System.out.println("Stack overflow");
		}
		else{
			top++;
			a[top]=x;
			System.out.println(x+" pushed into stack");
		}
	}
	
	void display(){
		System.out.println("Stack elements are:");
		while(top!=-1){
			System.out.println(a[top]);
			top--;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StackDemo s=new StackDemo();
		s.push(3);
		s.push(30);
		s.push(300);
		System.out.println(s.pop()+" popped from stack");
		s.display();
	}

}
