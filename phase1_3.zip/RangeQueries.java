package assistedpractice_phase1_3;
import java.util.*;
public class RangeQueries {
	static int n;
	static int a[];
	static void sum(int l,int r){
		int sum=0;
		for(int i=l;i<=r;i++){
			sum=sum+a[i];
		}
		System.out.println(sum);
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number of elements:");
		n=sc.nextInt();
		System.out.println("Enter the elements: ");
		a=new int[n];
		for(int i=0;i<n;i++)
			a[i]=sc.nextInt();
		sum(0,5);
		sum(3,5);
		sum(2,5);
	}

}
