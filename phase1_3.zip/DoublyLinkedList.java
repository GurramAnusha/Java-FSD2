package assistedpractice_phase1_3;

public class DoublyLinkedList {
	class Node{
		int data;
		Node previous;
		Node next;
		Node(int data){
			this.data=data;
		}
	}
	
	Node head,tail=null;
	
	void addNode(int data){
		Node newnode=new Node(data);
		if(head==null){
			head=tail=newnode;
			head.previous=null;
			tail.next=null;
		}
		else{
			tail.next=newnode;
			newnode.previous=tail;
			tail=newnode;
			tail.next=null;
		}
	}
	
	void displayFromHead(){
		Node current=head;
		if(head==null){
			System.out.println("List is empty");
		}
		else{
			System.out.println("Nodes in the linked list in forward direction: ");
			while(current!=null){
				System.out.print(current.data+" ");
				current=current.next;
			}
		}
	}
	
	void displayFromTail(){
		if(tail==null){
			System.out.println("List is empty");
		}
		else{
			Node current=tail;
			System.out.println("\nNodes in the linked list in backward direction: ");
			while(current!=null){
				System.out.print(current.data+" ");
				current=current.previous;
			
			}
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DoublyLinkedList dList = new DoublyLinkedList();  
        dList.addNode(1);  
        dList.addNode(2);  
        dList.addNode(3);  
        dList.addNode(4);  
        dList.addNode(5);  
      
        dList.displayFromHead();
        dList.displayFromTail();
  
  
	}

}
