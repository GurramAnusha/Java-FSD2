package assistedpractice_phase1_4;
import java.util.Scanner;

import java.util.*;
public class InsertionSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in=new Scanner(System.in);
		System.out.println("Enter the size of an array");
		int n=in.nextInt();
		System.out.println("Enter the elements in the array ");
		int a[]=new int[n];
		for(int i=0;i<n;i++)
			a[i]=in.nextInt();
		insertionSort(a,n);
		for(int i=0;i<n;i++)
			System.out.println(a[i]);

	}
	
	static void insertionSort(int a[],int n){
		for(int j=1;j<n;j++){
			int key=a[j];
			int i=j-1;
			while((i>-1)&&a[i]>key){
				a[i+1]=a[i];
				i--;
			}
			a[i+1]=key;
		}
	}

}
