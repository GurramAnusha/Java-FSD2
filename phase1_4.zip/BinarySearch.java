package assistedpractice_phase1_4;
import java.util.*;
public class BinarySearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in=new Scanner(System.in);
		System.out.println("Enter the size of an array");
		int n=in.nextInt();
		System.out.println("Enter the elements in the array ");
		int a[]=new int[n];
		for(int i=0;i<n;i++)
			a[i]=in.nextInt();
		System.out.println("Enter the element you want to search for :");
		int s=in.nextInt();
	    binarySearch(n,a,s,0);	
	}
	
	static void binarySearch(int n,int a[],int s,int start){
		int m=(start+n)/2;
		while(start<=n){
			if(a[m]==s){
				System.out.println("Element is found at:"+m);
				break;
			}
			else if(a[m]<s)
				start=m+1;
			else
				n=m-1;
			m=(start+n)/2;
		}
		if(start>n)
			System.out.println("element not found");
	}

}
