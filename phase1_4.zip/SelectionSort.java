package assistedpractice_phase1_4;
import java.util.*;
public class SelectionSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in=new Scanner(System.in);
		System.out.println("Enter the size of an array");
		int n=in.nextInt();
		System.out.println("Enter the elements in the array ");
		int a[]=new int[n];
		for(int i=0;i<n;i++)
			a[i]=in.nextInt();

		selectionSort(a,n);
		for(int i=0;i<n;i++)
			System.out.println(a[i]);

	}

	
	 static void selectionSort(int a[],int n){
		 for(int i=0;i<n;i++){
			 int index=i;
			 for(int j=i+1;j<n;j++){
				 if(a[j]<a[index])
					 index=j;
					 
			 }
		 
		 
		 int t=a[index];
		 a[index]=a[i];
		 a[i]=t;
		 
	 }
}
}