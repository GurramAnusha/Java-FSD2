package assistedpractice_phase1_4;

import java.util.*;
public class LinearSearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in=new Scanner(System.in);
		System.out.println("Enter the size of an array");
		int n=in.nextInt();
		System.out.println("Enter the elements in the array ");
		int a[]=new int[n];
		for(int i=0;i<n;i++)
			a[i]=in.nextInt();
		System.out.println("Enter the element you want to search for :");
		int s=in.nextInt();
		int result= linear(n,a,s);
		if(result==-1)
			System.out.println("Element not found");
		else
			System.out.println("Element is found at: "+result);
	}
	
	static int linear(int n,int a[],int s){
		for(int i=0;i<n;i++){
			if(a[i]==s)
				return i;
		}
		return -1;
		}

}
