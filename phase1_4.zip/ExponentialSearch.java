package assistedpractice_phase1_4;
import java.util.*;
public class ExponentialSearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner in=new Scanner(System.in);
		System.out.println("Enter the size of an array");
		int n=in.nextInt();
		System.out.println("Enter the elements in the array ");
		int a[]=new int[n];
		for(int i=0;i<n;i++)
			a[i]=in.nextInt();
		System.out.println("Enter the element you want to search for :");
		int s=in.nextInt();
		
		int outcome=exponentialSearch(a,n,s);
		if(outcome<0)
			System.out.println("Element is not present in the array");
		else
			System.out.println("Element is present in the array at index:"+outcome);
	}




static int exponentialSearch(int a[],int n,int s){
	if(a[0]==s)
		return 0;
	int i=1;
	while(i<n && a[i]<=s)
		i=i*2;
	return Arrays.binarySearch(a,i/2,Math.min(i,n),s);
}
}