package practiceprojects_servlets;

import java.io.IOException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.smartcardio.ResponseAPDU;

@WebServlet("/Product")
public class ProductServlet extends HttpServlet {
	
	public void service(HttpServletRequest req, HttpServletResponse resp) throws IOException{
		String p_id=req.getParameter("ProductId");
		String p_name=req.getParameter("ProductName");
		String p_price=req.getParameter("ProductPrice");
		
		HttpSession session= req.getSession();
		session.setAttribute("ProductId",p_id);
		session.setAttribute("ProductName",p_name);
		session.setAttribute("ProductPrice", p_price);
		
		resp.sendRedirect("DisplayProductDetails.jsp");
		
		
		
		
	}

}
