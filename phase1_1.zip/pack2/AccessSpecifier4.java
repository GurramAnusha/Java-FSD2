package pack2;
import pack1.PubAccessSpecifier;
public class AccessSpecifier4{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("public access specifier");
		PubAccessSpecifier pa=new PubAccessSpecifier();
		pa.display();

	}

}
