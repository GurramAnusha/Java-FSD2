package assistedpractice_phase1;

public class Type_Casting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//implicit typecasting
		System.out.println("Implicit TypeCasting...");
		char c='C';
		int i=c;
		float f=c;
		double d=c;
		long l=c;
		System.out.println("Value of c: "+c);
		System.out.println("Value of i: "+i);
		System.out.println("Value of f: "+f);
		System.out.println("Value of d: "+d);
		System.out.println("Value of l: "+l);
		
		//Explicit type casting
		System.out.println("Explicit TypeCasting....");
		double d1=234.32d;
		int i1=(int)d1;
		System.out.println("Value of d1: "+d1);
		System.out.println("Value of i1: "+i1);
		

	}

}
