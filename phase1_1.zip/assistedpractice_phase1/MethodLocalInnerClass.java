package assistedpractice_phase1;

public class MethodLocalInnerClass {
	
	private String msg="Inner Class";
	void display(){
		class Inner{
			void msg(){
				System.out.println(msg);
			}
		}
		Inner i=new Inner();
		i.msg();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MethodLocalInnerClass m=new MethodLocalInnerClass();
		m.display();
	}

}
