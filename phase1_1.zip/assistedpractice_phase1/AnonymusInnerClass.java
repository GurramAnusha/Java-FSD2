package assistedpractice_phase1;

abstract class AnonymusClass{
	public abstract void display();
}

public class AnonymusInnerClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AnonymusClass i=new AnonymusClass(){
			public void display(){
				System.out.println("Anonymus Inner Class");
			}
		};
		i.display();
	}

}
