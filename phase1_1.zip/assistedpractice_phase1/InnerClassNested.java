package assistedpractice_phase1;

public class InnerClassNested {
	
	private String msg="Welcom to Java";
	class Inner{
		void hello(){
			System.out.println(msg+",Let us start learning Inner Classes");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InnerClassNested i=new InnerClassNested();
		InnerClassNested.Inner i2=i.new Inner();
		i2.hello();
	}

}
