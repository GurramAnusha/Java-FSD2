package assistedpractice_phase1;

public class DefaultConstructor {
	int id;
	String name;
	void display(){
		System.out.println(id+" "+name);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DefaultConstructor dc=new DefaultConstructor();
		dc.display();

	}

}
