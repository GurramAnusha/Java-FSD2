package assistedpractice_phase1;

public class ArraysDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]={10,20,30,40,50};
		for(int i=0;i<5;i++)
			System.out.println("Elements of array a:"+a[i]);
		int b[][]={
				{2,3,4,5},
				{3,4,1}};
		System.out.println("Length of the row1:"+b[0].length);
	}

}
