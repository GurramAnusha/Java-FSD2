package assistedpractice_phase1;

public class ParameterizedConstructor {
	int id;
	String name;
	ParameterizedConstructor(int i,String n){
		id=i;
		name=n;
	}
	void display(){
		System.out.println(id+" "+name);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ParameterizedConstructor pc=new ParameterizedConstructor(2,"Anusha");
		ParameterizedConstructor pc1=new ParameterizedConstructor(3,"Anand");
		pc.display();
		pc1.display();
	}

}
