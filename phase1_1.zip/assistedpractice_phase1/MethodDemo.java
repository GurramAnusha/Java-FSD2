package assistedpractice_phase1;

public class MethodDemo {
	
	public int multiplyNumbers(int a,int b){
		int z=a*b;
		return z;
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MethodDemo md=new MethodDemo();
		int ans=md.multiplyNumbers(10, 3);
		System.out.println("Multiplication is: "+ans);
	}

}
