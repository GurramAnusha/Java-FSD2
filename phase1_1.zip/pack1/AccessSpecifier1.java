package pack1;

public class AccessSpecifier1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Default Access Speifier");
		DefAccessSpecifier da=new DefAccessSpecifier();
		da.display();

	}

}
