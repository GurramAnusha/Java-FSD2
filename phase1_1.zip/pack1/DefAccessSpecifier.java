package pack1;

public class DefAccessSpecifier {
	void display()//default access specifier method
	{
		System.out.println("You are using default access specifier");
	}

}
