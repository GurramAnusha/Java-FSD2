package pack1;

public class PubAccessSpecifier {
	public void display()//public access specifier method
	{
		System.out.println("You are using public access specifier");
	}

}
