package pack1;

public class PriAccessSpecifier {
	private void display()//private access specifier method
	{
		System.out.println("You are using private access specifier");
	}
}
