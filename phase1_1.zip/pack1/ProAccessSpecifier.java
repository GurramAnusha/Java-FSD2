package pack1;

public class ProAccessSpecifier {
	protected void display()//protected access specifier method
	{
		System.out.println("You are using protected access specifier");
	}

}
